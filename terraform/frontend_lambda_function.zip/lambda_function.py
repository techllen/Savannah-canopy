# lambda function integrated with an AI agent
import json
import boto3
import base64
import os

lambda_client = boto3.client('lambda')

bedrock_runtime = boto3.client(service_name='bedrock-runtime')
model_id = os.environ['BEDROCK_MODEL_ID'] # get id from env variable

def lambda_handler(event, context):
    # Ensure the `awslogs` key exists
    if 'awslogs' not in event or 'data' not in event['awslogs']:
        print("Invalid event format: Missing 'awslogs.data'")
        return {'statusCode': 400, 'body': 'Invalid event format'}

    # Decode log data
    data = base64.b64decode(event['awslogs']['data'])
    log_data = json.loads(data)

    for log_event in log_data.get('logEvents', []):
        message = log_event.get('message', '')

        if "ERROR" in message:
            print(f"Error message: {message}")
            try:
                # Compiling a prompt
                prompt = f'As an software engineer Provide a solution and test cases for this error: {message}'

                payload = {
                    "prompt": f"<s>[INST] {prompt} [/INST]",
                    "max_tokens": 500,
                    "temperature": 0.5
                }
                # *** AI AGENT INVOCATION ***
                # The following call sends the error message as a prompt to the Amazon Bedrock model.
                # Agentic behavior.
                response = bedrock_runtime.invoke_model(
                    modelId=model_id,
                    accept='application/json',
                    contentType='application/json',
                    body=json.dumps(payload),
                )

                response_body = json.loads(response['body'].read())
                generated_text = response_body['outputs'][0]['text']
                # print(f"Bedrock response: {generated_text}")

                # *** INVOKE POST-PROCESSING LAMBDA ***
                invoke_response = lambda_client.invoke(
                    FunctionName='post-process-ai-agent-output-lambda',
                    InvocationType='RequestResponse',
                    Payload=json.dumps({'body': json.dumps({'generated_text': generated_text})})
                )

                post_process_result = json.loads(invoke_response['Payload'].read())
                print(f"Post-processed result: {post_process_result}")

            except Exception as e:
                print(f"Error invoking Bedrock: {e}")

# Return the AI agent's output.
    return {
        'statusCode': 200,
        'body': json.dumps({'generated_text': generated_text})
    }
