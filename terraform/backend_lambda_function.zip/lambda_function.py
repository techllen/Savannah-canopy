import json
import boto3

bedrock_runtime = boto3.client(service_name='bedrock-runtime')
model_id = 'mistral.mistral-7b-instruct-v1'

def lambda_handler(event, context):
    log_events = event['awslogs']['data']
    decoded_logs = json.loads(log_events)
    for log_event in decoded_logs['logEvents']:
        message = log_event['message']
        if "ERROR" in message:
            print(f"Error message: {message}")
            try:
                prompt = f"Explain the following error message and suggest possible solutions: {message}"
                body = json.dumps({
                    "prompt": prompt,
                    "max_tokens": 500,
                    "temperature": 0.5,
                })

                response = bedrock_runtime.invoke_model(body=body, modelId=model_id, contentType='application/json')
                response_body = json.loads(response.get('body').read())
                completion = response_body['generation']
                print(f"Bedrock response: {completion}")

            except Exception as e:
                print(f"Error invoking Bedrock: {e}")

    return {
        'statusCode': 200,
        'body': json.dumps('Logs processed!')
    }
