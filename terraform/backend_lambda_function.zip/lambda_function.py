import json
import boto3
import base64
import os

bedrock_runtime = boto3.client(service_name='bedrock-runtime')
model_id = os.environ['BEDROCK_MODEL_ID'] # get id from env variable

def lambda_handler(event, context):
    # Ensure the `awslogs` key exists
    if 'awslogs' not in event or 'data' not in event['awslogs']:
        print("Invalid event format: Missing 'awslogs.data'")
        return {'statusCode': 400, 'body': 'Invalid event format'}

    # Decode log data
    data = base64.b64decode(event['awslogs']['data'])
    log_data = json.loads(data)

    for log_event in log_data.get('logEvents', []):
        message = log_event.get('message', '')

        if "ERROR" in message:
            print(f"Error message: {message}")
            try:
                prompt = f"Explain the following error message and suggest possible solutions: {message}"
                body = json.dumps({
                    "prompt": prompt,
                    "max_tokens": 500,
                    "temperature": 0.5,
                })

                response = bedrock_runtime.invoke_model(
                    body=body,
                    modelId=model_id,
                    contentType='application/json'
                )

                response_body = json.loads(response.get('body', {}).read().decode('utf-8'))
                completion = response_body.get('generation', 'No response generated')
                print(f"Bedrock response: {completion}")

            except Exception as e:
                print(f"Error invoking Bedrock: {e}")

    return {
        'statusCode': 200,
        'body': json.dumps('Logs processed!')
    }
