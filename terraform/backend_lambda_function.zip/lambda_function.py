import json

def lambda_handler(event, context):
    log_events = event['awslogs']['data']
    decoded_logs = json.loads(log_events)
    for log_event in decoded_logs['logEvents']:
        message = log_event['message']
        if "ERROR" in message:
            print(message)
    return {
        'statusCode': 200,
        'body': json.dumps('Logs processed!')
    }
